package com.irina.show.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.irina.show.services.BookService;

@Controller

public class home {
	@Autowired
	private BookService bService;
	
	@GetMapping("/")
	public String frontpage(Model viewModel) {
		viewModel.addAttribute("allbooks", this.bService.getAllBooks());
		return "index.jsp";
	}
	
	@GetMapping("/add")
	public String addbook() {
		return "new.jsp";
	}
	
	@PostMapping("/new")
	public String newbook(@RequestParam("fname") String name, @RequestParam("desc") String description, @RequestParam("lang") String language, @RequestParam("noPages") int noPages) {
		this.bService.createBook2(name, description, language, noPages);
		return "redirect:/";
		
		
	}
	
	
	

}
