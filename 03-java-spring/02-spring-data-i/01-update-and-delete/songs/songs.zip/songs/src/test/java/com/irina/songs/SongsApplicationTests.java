package com.irina.songs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SongsApplicationTests {

	@Test
	void contextLoads() {
	}

}
