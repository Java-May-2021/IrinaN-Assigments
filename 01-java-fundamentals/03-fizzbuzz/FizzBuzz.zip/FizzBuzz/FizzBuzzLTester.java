public class FizzBuzzLTester {
    public static void main(String[] args) {
        FizzBuzzL fb = new FizzBuzzL();
        fb.display();
    }
}
